# Developing

* Issues should be filed at [Drupal.org].
* Code changes can be submitted in the patch form and uploaded to the Drupal.org
  issue or as a [GitHub pull request].

[Drupal.org]: http://drupal.org/project/issues/media_entity_image
[GitHub pull request]: https://github.com/drupal-media/media_entity_image/pulls
