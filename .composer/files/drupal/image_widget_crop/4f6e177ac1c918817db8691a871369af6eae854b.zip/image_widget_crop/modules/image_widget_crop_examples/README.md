ImageWidgetCrop Examples module
==============================

Provides an out of box examples implementation of ImageWidgetCrop.

Requirement
-----------
You must have "BARTIK" theme installed to install this module.

Modules:

* inline_entity_form
* image_widget_crop
* crop

Configuration
-------------

* Create an content to test differents cases.
    * Create Crop Media Example (`node/add/crop_media_example`)
    * Create Crop Responsive Example (`node/add/crop_responsive_example`)
    * Create Crop Simple Example (`node/add/crop_simple_example`)
