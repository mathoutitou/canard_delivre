Entity Embed Link

This is a module that is meant to cleanly address the issue with
Entity Embed that prevents images from being rendered as links:

https://www.drupal.org/node/2511404

This module is completely unmaintained, and will hopefully become
unnecessary in the future once the issue is fixed.
