<?php

namespace Drupal\media_entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;

final class MediaBundle extends ConfigEntityBase {
}
