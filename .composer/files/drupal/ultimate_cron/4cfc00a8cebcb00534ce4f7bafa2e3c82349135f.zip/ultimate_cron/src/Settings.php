<?php

namespace Drupal\ultimate_cron;

use Drupal\Core\Form\FormBase;

/**
 * Base class for settings.
 *
 * There's nothing special about this plugin.
 */
class Settings extends CronPluginMultiple {
}
