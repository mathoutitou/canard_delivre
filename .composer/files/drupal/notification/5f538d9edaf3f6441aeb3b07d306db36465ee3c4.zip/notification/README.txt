Notification

Installation
============

This module requires the core CKEditor module.

1. Download the plugin from http://ckeditor.com/addon/notification at least version 4.5.11.
2. Place the plugin in the root libraries folder (/libraries).
3. Enable Notification module in the Drupal admin.