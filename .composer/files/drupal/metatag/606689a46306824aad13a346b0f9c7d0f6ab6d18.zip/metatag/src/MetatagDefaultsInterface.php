<?php

namespace Drupal\metatag;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Metatag defaults entities.
 */
interface MetatagDefaultsInterface extends ConfigEntityInterface {
  // Add get/set methods for your configuration properties here.
}
