## DESCRIPTION

Simple end point for load balancers to check Drupal site health
