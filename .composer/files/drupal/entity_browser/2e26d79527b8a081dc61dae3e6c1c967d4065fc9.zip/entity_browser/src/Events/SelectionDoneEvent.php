<?php

namespace Drupal\entity_browser\Events;

/**
 * Represents finished selection as event.
 */
class SelectionDoneEvent extends EventBase {

}
