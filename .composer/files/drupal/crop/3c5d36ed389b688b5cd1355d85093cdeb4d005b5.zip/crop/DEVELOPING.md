# Developing

* Issues should be filed at http://drupal.org/project/issues/crop
* Pull requests can be made against https://github.com/drupal-media/crop/pulls
